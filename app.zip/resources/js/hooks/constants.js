export const useDefaultPhoto = (abc) => {
  return `https://ui-avatars.com/api/?name='.urlencode(${abc}).'&color=7F9CF5&background=EBF4FF`;
}
